import 'package:flutter_test/flutter_test.dart';
import 'package:vnexpress_news_reader/models/news_article.dart';
import 'package:vnexpress_news_reader/models/news_category.dart';

void main() {
  group('Kiểm thử mô hình NewsArticle', () {
    test('Trích xuất ảnh thành công từ chuỗi thẻ img HTML', () {
      const html = '<a href="https://vnexpress.net/bai-viet.html"><img src="https://i1-vnexpress.vnecdn.net/2026/09/sample.jpg?w=1200"></a></br>Mô tả ngắn';
      final img = NewsArticle.extractImageUrl(html);
      expect(img, 'https://i1-vnexpress.vnecdn.net/2026/09/sample.jpg?w=1200');
    });

    test('Làm sạch mã HTML và các entities khỏi phần mô tả', () {
      const html = '<a href="#">Ảnh</a></br>Đây là đoạn &quot;tin tức&quot; mẫu &amp; thử nghiệm.';
      final cleaned = NewsArticle.cleanDescription(html);
      expect(cleaned, 'Đây là đoạn "tin tức" mẫu & thử nghiệm.');
    });

    test('Định dạng ngày tháng chuẩn hiển thị', () {
      final article = NewsArticle(
        title: 'Tiêu đề thử nghiệm',
        description: 'Mô tả thử nghiệm',
        link: 'https://vnexpress.net',
        pubDateRaw: 'Mon, 28 Sep 2026 17:14:07 +0700',
        pubDate: DateTime(2026, 9, 28, 17, 14),
      );
      expect(article.formattedDate, '28 Sep 2026');
      expect(article.formattedDateTime, '17:14 - 28/09/2026');
    });
  });

  group('Kiểm thử danh mục NewsCategory', () {
    test('Danh sách chủ đề mặc định có đầy đủ các chuyên mục chính', () {
      final categories = NewsCategory.defaultCategories;
      expect(categories.isNotEmpty, true);
      expect(categories.any((c) => c.name == 'Thời sự'), true);
      expect(categories.any((c) => c.name == 'Thế giới'), true);
      expect(categories.any((c) => c.name == 'Kinh doanh'), true);
      expect(categories.any((c) => c.name == 'Tin tổng hợp'), true);
    });
  });
}
