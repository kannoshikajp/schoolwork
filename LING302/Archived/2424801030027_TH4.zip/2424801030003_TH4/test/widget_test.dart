import 'package:flutter_test/flutter_test.dart';
import 'package:vnexpress_news_reader/main.dart';

void main() {
  testWidgets('Kiểm tra khởi tạo ứng dụng Đọc Báo Online', (WidgetTester tester) async {
    await tester.pumpWidget(const NewsReaderApp());
    expect(find.text('ĐỌC BÁO ONLINE'), findsOneWidget);
    expect(find.text('Tin tổng hợp'), findsOneWidget);
  });
}
