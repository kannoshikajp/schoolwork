# BÀI TẬP THỰC HÀNH 4: ỨNG DỤNG ĐỌC BÁO ONLINE (VNEXPRESS RSS)

**Môn học:** Lập trình ứng dụng đa nền tảng  
**Họ và tên:** Nguyễn Hoàng Phúc  
**Mã số sinh viên (MSSV):** 2424801030003  
**Lớp:** KTPM02  
**Thư mục dự án:** `2424801030003_TH4`  

---

## Các tính năng chính

1. **Màn hình chính (Tin tổng hợp)**:
   - Cài đặt giao diện đúng theo hình minh họa trong đề bài.
   - Tiêu đề AppBar: `ĐỌC BÁO ONLINE` (căn giữa, in hoa, chữ đậm).
   - Nút Refresh ở bên phải thanh AppBar.
   - Danh sách tin tức tổng hợp từ kênh RSS VnExpress.
   - Tiêu đề in đậm, nguồn VnExpress, ngày xuất bản; ảnh thumbnail bên phải bo tròn góc.
   - Vuốt xuống để làm mới (Pull-to-refresh).

2. **Màn hình chi tiết bài báo**:
   - Mở ra khi chạm vào bất kỳ bài báo nào.
   - Hiển thị đầy đủ thông tin: Tiêu đề lớn, danh mục, thời gian đăng tin, ảnh chất lượng cao, tóm tắt nội dung.
   - Nút `ĐỌC TOÀN BỘ BÀI VIẾT TRÊN VNEXPRESS` mở bài báo gốc trên trình duyệt qua `url_launcher`.
   - Nút chia sẻ / sao chép liên kết vào Clipboard.

3. **Màn hình theo chủ đề**:
   - Phân loại các chủ đề: Thời sự, Thế giới, Kinh doanh, Thể thao, Giải trí, Sức khỏe, Đời sống, Du lịch, Khoa học, Số hóa, Xe, Giáo dục, Pháp luật.
   - Chọn chủ đề và tải tức thì tin tức tương ứng.
   - Thanh tìm kiếm bài báo trong từng chủ đề.

4. **Màn hình tin mới nhất (Top 10)**:
   - Tải và hiển thị đúng 10 tin mới nhất từ VnExpress RSS.
   - Đánh số thứ tự badge từ 1 đến 10 với màu sắc nổi bật.

5. **Màn hình cài đặt**:
   - Thiết lập giao diện: Chế độ sáng / tối (Dark mode) chuyển đổi toàn hệ thống, tự động lưu với SharedPreferences.
   - Tùy chỉnh cỡ chữ đọc bài báo (Nhỏ, Chuẩn, Lớn).
   - Hiển thị đầy đủ thông tin sinh viên: Họ tên (Nguyễn Hoàng Phúc), MSSV (2424801030003), Lớp (KTPM02).
   - Tiện ích xóa bộ nhớ đệm và hộp thoại thông tin ứng dụng.

---

## Hướng dẫn chạy ứng dụng

```bash
# Cài đặt thư viện
flutter pub get

# Kiểm tra mã nguồn
dart analyze

# Chạy kiểm thử tự động
flutter test

# Chạy ứng dụng trên thiết bị / máy ảo
flutter run
```
