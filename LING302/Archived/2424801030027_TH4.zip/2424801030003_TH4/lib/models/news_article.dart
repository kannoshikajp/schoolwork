import 'package:intl/intl.dart';

class NewsArticle {
  final String title;
  final String description;
  final String link;
  final DateTime? pubDate;
  final String pubDateRaw;
  final String? imageUrl;
  final String category;
  final String source;

  NewsArticle({
    required this.title,
    required this.description,
    required this.link,
    this.pubDate,
    required this.pubDateRaw,
    this.imageUrl,
    this.category = 'Tổng hợp',
    this.source = 'VnExpress',
  });

  /// Trích xuất URL ảnh từ chuỗi HTML
  static String? extractImageUrl(String htmlContent) {
    if (htmlContent.isEmpty) return null;
    final imgRegex = RegExp(r'<img[^>]+src="([^"]+)"', caseSensitive: false);
    final match = imgRegex.firstMatch(htmlContent);
    if (match != null && match.groupCount >= 1) {
      final url = match.group(1);
      if (url != null && url.startsWith('http')) {
        return url;
      }
    }
    // Thử trường hợp dùng dấu nháy đơn
    final singleQuoteRegex = RegExp("<img[^>]+src='([^']+)'", caseSensitive: false);
    final singleMatch = singleQuoteRegex.firstMatch(htmlContent);
    if (singleMatch != null && singleMatch.groupCount >= 1) {
      final url = singleMatch.group(1);
      if (url != null && url.startsWith('http')) {
        return url;
      }
    }
    return null;
  }

  /// Làm sạch mô tả từ chuỗi HTML có lẫn thẻ <a>, <img>, <br>...
  static String cleanDescription(String rawHtml) {
    if (rawHtml.isEmpty) return '';

    // Loại bỏ thẻ <a><img>...</a>
    String cleaned = rawHtml.replaceAll(RegExp(r'<a\b[^>]*>(.*?)</a>', caseSensitive: false), '');
    // Loại bỏ toàn bộ thẻ HTML còn lại
    cleaned = cleaned.replaceAll(RegExp(r'<[^>]*>'), '');
    // Thay thế các HTML entities thường gặp
    cleaned = cleaned
        .replaceAll('&quot;', '"')
        .replaceAll('&apos;', "'")
        .replaceAll('&#39;', "'")
        .replaceAll('&amp;', '&')
        .replaceAll('&lt;', '<')
        .replaceAll('&gt;', '>')
        .replaceAll('&nbsp;', ' ')
        .replaceAll('&#160;', ' ');

    return cleaned.trim();
  }

  /// Parse ngày tháng từ chuỗi chuẩn RFC-822 / RSS (vd: Mon, 28 Sep 2026 17:14:07 +0700)
  static DateTime? parseRssDate(String dateStr) {
    if (dateStr.isEmpty) return null;
    try {
      final format = DateFormat('EEE, dd MMM yyyy HH:mm:ss Z', 'en_US');
      return format.parse(dateStr);
    } catch (_) {
      try {
        return DateTime.tryParse(dateStr);
      } catch (_) {
        return null;
      }
    }
  }

  /// Hiển thị ngày tháng theo phong cách VnExpress (vd: "28 Sep 2026")
  String get formattedDate {
    if (pubDate != null) {
      return DateFormat('dd MMM yyyy').format(pubDate!);
    }
    if (pubDateRaw.isNotEmpty) {
      final parts = pubDateRaw.split(' ');
      if (parts.length >= 4) {
        return '${parts[1]} ${parts[2]} ${parts[3]}';
      }
      return pubDateRaw;
    }
    return 'Hôm nay';
  }

  /// Hiển thị ngày giờ đầy đủ cho màn hình chi tiết (vd: 15:10 - 29/09/2026)
  String get formattedDateTime {
    final date = pubDate ?? parseRssDate(pubDateRaw);
    if (date != null) {
      return DateFormat('HH:mm - dd/MM/yyyy').format(date);
    }
    if (pubDateRaw.isNotEmpty) {
      final parts = pubDateRaw.split(' ');
      if (parts.length >= 5) {
        final time = parts[4].length >= 5 ? parts[4].substring(0, 5) : parts[4];
        return '$time - ${parts[1]} ${parts[2]} ${parts[3]}';
      }
      return pubDateRaw;
    }
    return 'Mới cập nhật';
  }
}
