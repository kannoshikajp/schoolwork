import 'package:flutter/material.dart';

class NewsCategory {
  final String id;
  final String name;
  final String rssUrl;
  final IconData icon;
  final Color color;

  const NewsCategory({
    required this.id,
    required this.name,
    required this.rssUrl,
    required this.icon,
    this.color = Colors.blue,
  });

  /// Danh sách các chủ đề phân loại của VnExpress
  static const List<NewsCategory> defaultCategories = [
    NewsCategory(
      id: 'trang_chu',
      name: 'Tin tổng hợp',
      rssUrl: 'https://vnexpress.net/rss/tin-moi-nhat.rss',
      icon: Icons.newspaper,
      color: Colors.red,
    ),
    NewsCategory(
      id: 'thoi_su',
      name: 'Thời sự',
      rssUrl: 'https://vnexpress.net/rss/thoi-su.rss',
      icon: Icons.public,
      color: Colors.blue,
    ),
    NewsCategory(
      id: 'the_gioi',
      name: 'Thế giới',
      rssUrl: 'https://vnexpress.net/rss/the-gioi.rss',
      icon: Icons.language,
      color: Colors.indigo,
    ),
    NewsCategory(
      id: 'kinh_doanh',
      name: 'Kinh doanh',
      rssUrl: 'https://vnexpress.net/rss/kinh-doanh.rss',
      icon: Icons.trending_up,
      color: Colors.green,
    ),
    NewsCategory(
      id: 'the_thao',
      name: 'Thể thao',
      rssUrl: 'https://vnexpress.net/rss/the-thao.rss',
      icon: Icons.sports_soccer,
      color: Colors.orange,
    ),
    NewsCategory(
      id: 'giai_tri',
      name: 'Giải trí',
      rssUrl: 'https://vnexpress.net/rss/giai-tri.rss',
      icon: Icons.movie,
      color: Colors.purple,
    ),
    NewsCategory(
      id: 'suc_khoe',
      name: 'Sức khỏe',
      rssUrl: 'https://vnexpress.net/rss/suc-khoe.rss',
      icon: Icons.medical_services,
      color: Colors.teal,
    ),
    NewsCategory(
      id: 'doi_song',
      name: 'Đời sống',
      rssUrl: 'https://vnexpress.net/rss/gia-dinh.rss',
      icon: Icons.family_restroom,
      color: Colors.pink,
    ),
    NewsCategory(
      id: 'du_lich',
      name: 'Du lịch',
      rssUrl: 'https://vnexpress.net/rss/du-lich.rss',
      icon: Icons.flight_takeoff,
      color: Colors.cyan,
    ),
    NewsCategory(
      id: 'khoa_hoc',
      name: 'Khoa học',
      rssUrl: 'https://vnexpress.net/rss/khoa-hoc.rss',
      icon: Icons.science,
      color: Colors.amber,
    ),
    NewsCategory(
      id: 'so_hoa',
      name: 'Số hóa - Công nghệ',
      rssUrl: 'https://vnexpress.net/rss/so-hoa.rss',
      icon: Icons.devices,
      color: Colors.deepPurple,
    ),
    NewsCategory(
      id: 'oto_xe_may',
      name: 'Xe',
      rssUrl: 'https://vnexpress.net/rss/oto-xe-may.rss',
      icon: Icons.directions_car,
      color: Colors.blueGrey,
    ),
    NewsCategory(
      id: 'giao_duc',
      name: 'Giáo dục',
      rssUrl: 'https://vnexpress.net/rss/giao-duc.rss',
      icon: Icons.school,
      color: Colors.brown,
    ),
    NewsCategory(
      id: 'phap_luat',
      name: 'Pháp luật',
      rssUrl: 'https://vnexpress.net/rss/phap-luat.rss',
      icon: Icons.gavel,
      color: Colors.redAccent,
    ),
  ];
}
