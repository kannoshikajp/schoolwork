import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ThemeController extends ChangeNotifier {
  static final ThemeController instance = ThemeController._internal();
  ThemeController._internal();

  static const String _keyDarkMode = 'is_dark_mode';
  static const String _keyFontSize = 'font_size_scale';

  bool _isDarkMode = false;
  double _fontSizeScale = 1.0;

  bool get isDarkMode => _isDarkMode;
  double get fontSizeScale => _fontSizeScale;

  ThemeMode get themeMode => _isDarkMode ? ThemeMode.dark : ThemeMode.light;

  /// Khởi tạo và đọc giá trị đã lưu
  Future<void> init() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      _isDarkMode = prefs.getBool(_keyDarkMode) ?? false;
      _fontSizeScale = prefs.getDouble(_keyFontSize) ?? 1.0;
      notifyListeners();
    } catch (e) {
      debugPrint('[ThemeController] Không thể đọc cài đặt từ SharedPreferences: $e');
    }
  }

  /// Bật / tắt giao diện tối
  Future<void> setDarkMode(bool isDark) async {
    _isDarkMode = isDark;
    notifyListeners();
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool(_keyDarkMode, isDark);
    } catch (_) {}
  }

  /// Cài đặt tỉ lệ cỡ chữ
  Future<void> setFontSizeScale(double scale) async {
    _fontSizeScale = scale;
    notifyListeners();
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setDouble(_keyFontSize, scale);
    } catch (_) {}
  }
}
