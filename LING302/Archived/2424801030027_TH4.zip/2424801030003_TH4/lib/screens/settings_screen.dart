import 'package:flutter/material.dart';
import '../theme/theme_controller.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  // Thông tin sinh viên theo yêu cầu đề bài
  final String studentName = 'Trần Phạm Thanh Trung';
  final String studentClass = 'KTPM02';
  final String studentId = '2424801030027';
  final String courseName = 'Lập trình ứng dụng đa nền tảng';
  final String appTitle = 'Ứng dụng đọc báo Online (VnExpress RSS)';
  final String appVersion = '1.0.0 (Bài tập 4)';

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = ThemeController.instance.isDarkMode;

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'CÀI ĐẶT',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
      ),
      body: ListenableBuilder(
        listenable: ThemeController.instance,
        builder: (context, _) {
          return ListView(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            children: [
              // 1. THẺ THÔNG TIN ỨNG DỤNG & SINH VIÊN THỰC HIỆN
              _buildSectionHeader('THÔNG TIN SINH VIÊN & ỨNG DỤNG'),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    children: [
                      Row(
                        children: [
                          CircleAvatar(
                            radius: 30,
                            backgroundColor: const Color(0xFF9E1B32),
                            child: const Text(
                              'NHP',
                              style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 18,
                              ),
                            ),
                          ),
                          const SizedBox(width: 16),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  studentName,
                                  style: const TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 18,
                                  ),
                                ),
                                const SizedBox(height: 4),
                                Text(
                                  'MSSV: $studentId',
                                  style: TextStyle(
                                    fontSize: 14,
                                    color: theme.colorScheme.primary,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                                Text(
                                  'Lớp: $studentClass',
                                  style: TextStyle(
                                    fontSize: 14,
                                    color: Colors.grey.shade600,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      const Divider(height: 24),
                      _buildInfoRow(Icons.school_outlined, 'Học phần', courseName),
                      const SizedBox(height: 8),
                      _buildInfoRow(Icons.assignment_outlined, 'Bài tập', 'Bài tập 4: Đọc báo online'),
                      const SizedBox(height: 8),
                      _buildInfoRow(Icons.rss_feed_rounded, 'Nguồn cấp tin', 'VnExpress Official RSS 2.0'),
                      const SizedBox(height: 8),
                      _buildInfoRow(Icons.info_outline, 'Phiên bản', appVersion),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 20),

              // 2. THIẾT LẬP GIAO DIỆN (SÁNG / TỐI)
              _buildSectionHeader('THIẾT LẬP GIAO DIỆN'),
              Card(
                child: Column(
                  children: [
                    SwitchListTile(
                      secondary: Icon(
                        isDark ? Icons.dark_mode : Icons.light_mode,
                        color: isDark ? Colors.amber : const Color(0xFF9E1B32),
                      ),
                      title: const Text(
                        'Chế độ nền tối (Dark mode)',
                        style: TextStyle(fontWeight: FontWeight.w600),
                      ),
                      subtitle: Text(
                        isDark ? 'Đang bật nền tối dịu mắt' : 'Đang sử dụng nền sáng chuẩn',
                        style: TextStyle(
                          fontSize: 12,
                          color: Colors.grey.shade600,
                        ),
                      ),
                      value: ThemeController.instance.isDarkMode,
                      activeTrackColor: const Color(0xFF9E1B32),
                      onChanged: (val) {
                        ThemeController.instance.setDarkMode(val);
                      },
                    ),
                    const Divider(),
                    ListTile(
                      leading: const Icon(Icons.format_size, color: Color(0xFF9E1B32)),
                      title: const Text(
                        'Cỡ chữ khi đọc bài báo',
                        style: TextStyle(fontWeight: FontWeight.w600),
                      ),
                      subtitle: Text(
                        ThemeController.instance.fontSizeScale == 0.9
                            ? 'Đang chọn: Cỡ chữ nhỏ (90%)'
                            : ThemeController.instance.fontSizeScale == 1.15
                                ? 'Đang chọn: Cỡ chữ lớn (115%)'
                                : 'Đang chọn: Cỡ chữ chuẩn (100%)',
                        style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                      child: SizedBox(
                        width: double.infinity,
                        child: SegmentedButton<double>(
                          showSelectedIcon: false,
                          style: const ButtonStyle(
                            visualDensity: VisualDensity.compact,
                            tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                          ),
                          segments: const [
                            ButtonSegment(
                              value: 0.9,
                              label: Text('Nhỏ (A-)'),
                            ),
                            ButtonSegment(
                              value: 1.0,
                              label: Text('Chuẩn (A)'),
                            ),
                            ButtonSegment(
                              value: 1.15,
                              label: Text('Lớn (A+)'),
                            ),
                          ],
                          selected: {ThemeController.instance.fontSizeScale},
                          onSelectionChanged: (Set<double> newSelection) {
                            ThemeController.instance.setFontSizeScale(newSelection.first);
                          },
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),

              // 3. TIỆN ÍCH KHÁC
              _buildSectionHeader('HỆ THỐNG & DỮ LIỆU'),
              Card(
                child: Column(
                  children: [
                    ListTile(
                      leading: const Icon(Icons.cleaning_services_outlined, color: Colors.blueGrey),
                      title: const Text('Xóa bộ nhớ đệm (Cache)'),
                      subtitle: const Text('Làm mới toàn bộ dữ liệu tin tức đã tải'),
                      trailing: const Icon(Icons.chevron_right),
                      onTap: () {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                            content: Text('Đã làm sạch bộ nhớ tạm ứng dụng thành công!'),
                            duration: Duration(seconds: 2),
                          ),
                        );
                      },
                    ),
                    const Divider(),
                    ListTile(
                      leading: const Icon(Icons.help_outline, color: Colors.blueGrey),
                      title: const Text('Giới thiệu ứng dụng'),
                      subtitle: const Text('Hướng dẫn sử dụng và bản quyền'),
                      trailing: const Icon(Icons.chevron_right),
                      onTap: () => _showAboutAppDialog(context),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 30),
            ],
          );
        },
      ),
    );
  }

  Widget _buildSectionHeader(String title) {
    return Padding(
      padding: const EdgeInsets.only(left: 4, bottom: 8),
      child: Text(
        title,
        style: TextStyle(
          fontSize: 12,
          fontWeight: FontWeight.bold,
          color: Theme.of(context).colorScheme.primary,
          letterSpacing: 0.8,
        ),
      ),
    );
  }

  Widget _buildInfoRow(IconData icon, String label, String value) {
    return Row(
      children: [
        Icon(icon, size: 18, color: Colors.grey.shade600),
        const SizedBox(width: 8),
        Text(
          '$label: ',
          style: TextStyle(
            fontSize: 13,
            color: Colors.grey.shade600,
          ),
        ),
        Expanded(
          child: Text(
            value,
            textAlign: TextAlign.right,
            style: const TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
      ],
    );
  }

  void _showAboutAppDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Row(
          children: [
            Icon(Icons.newspaper, color: Color(0xFF9E1B32)),
            SizedBox(width: 10),
            Text('Đọc Báo Online'),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Ứng dụng đọc báo trực tuyến tổng hợp tin tức nhanh 24/7 từ hệ thống RSS chính thức của Báo điện tử VnExpress.',
              style: TextStyle(fontSize: 14, height: 1.4),
            ),
            const SizedBox(height: 12),
            const Text(
              'Phát triển bởi:',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13),
            ),
            Text('• Sinh viên: $studentName'),
            Text('• MSSV: $studentId'),
            Text('• Lớp: $studentClass'),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Đóng'),
          ),
        ],
      ),
    );
  }
}
