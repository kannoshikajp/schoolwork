import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';
import '../models/news_article.dart';
import '../theme/theme_controller.dart';

class ArticleDetailScreen extends StatelessWidget {
  final NewsArticle article;

  const ArticleDetailScreen({super.key, required this.article});

  Future<void> _openOriginalArticle(BuildContext context) async {
    final uri = Uri.parse(article.link);
    try {
      if (await canLaunchUrl(uri)) {
        await launchUrl(uri, mode: LaunchMode.externalApplication);
      } else {
        if (context.mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Không thể mở liên kết bài báo')),
          );
        }
      }
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Lỗi khi mở liên kết: $e')),
        );
      }
    }
  }

  void _shareArticle(BuildContext context) {
    Clipboard.setData(ClipboardData(text: '${article.title}\n${article.link}'));
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Đã sao chép liên kết bài viết vào bộ nhớ tạm!'),
        duration: Duration(seconds: 2),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;
    final fontSizeScale = ThemeController.instance.fontSizeScale;

    return Scaffold(
      appBar: AppBar(
        title: Text(
          article.category.isNotEmpty ? article.category : 'Chi tiết tin tức',
          style: const TextStyle(fontSize: 16),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.share_outlined),
            tooltip: 'Chia sẻ bài viết',
            onPressed: () => _shareArticle(context),
          ),
          IconButton(
            icon: const Icon(Icons.open_in_browser),
            tooltip: 'Mở bài gốc trên VnExpress',
            onPressed: () => _openOriginalArticle(context),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Tag chuyên mục
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: const Color(0xFF9E1B32).withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(4),
              ),
              child: Text(
                article.category,
                style: const TextStyle(
                  color: Color(0xFF9E1B32),
                  fontWeight: FontWeight.bold,
                  fontSize: 12,
                ),
              ),
            ),
            const SizedBox(height: 12),

            // Tiêu đề bài viết
            Text(
              article.title,
              style: theme.textTheme.headlineSmall?.copyWith(
                fontWeight: FontWeight.bold,
                height: 1.35,
                fontSize: 22 * fontSizeScale,
                color: isDark ? Colors.white : Colors.black87,
              ),
            ),
            const SizedBox(height: 12),

            // Nguồn & Thời gian (Dùng Wrap chống tràn viền trên màn hình nhỏ)
            Wrap(
              crossAxisAlignment: WrapCrossAlignment.center,
              spacing: 12,
              runSpacing: 4,
              children: [
                Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(
                      Icons.access_time,
                      size: 15,
                      color: Colors.grey,
                    ),
                    const SizedBox(width: 5),
                    Text(
                      article.formattedDateTime,
                      style: TextStyle(
                        fontSize: 13,
                        color: isDark ? Colors.grey.shade400 : Colors.grey.shade600,
                      ),
                    ),
                  ],
                ),
                Text(
                  'Nguồn: ${article.source}',
                  style: const TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                    color: Color(0xFF9E1B32),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),

            // Ảnh lớn bài viết
            if (article.imageUrl != null && article.imageUrl!.isNotEmpty)
              ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: Image.network(
                  article.imageUrl!,
                  width: double.infinity,
                  fit: BoxFit.cover,
                  errorBuilder: (context, error, stackTrace) => const SizedBox.shrink(),
                ),
              ),
            if (article.imageUrl != null && article.imageUrl!.isNotEmpty)
              const SizedBox(height: 16),

            // Nội dung tóm tắt
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: isDark ? Colors.grey.shade900 : const Color(0xFFF1F3F5),
                borderRadius: BorderRadius.circular(10),
                border: Border(
                  left: BorderSide(
                    color: const Color(0xFF9E1B32),
                    width: 4,
                  ),
                ),
              ),
              child: Text(
                article.description.isNotEmpty
                    ? article.description
                    : 'Bấm vào nút bên dưới để đọc toàn bộ bài viết chi tiết trên báo VnExpress.',
                style: TextStyle(
                  fontSize: 16 * fontSizeScale,
                  height: 1.6,
                  color: isDark ? Colors.white70 : Colors.black87,
                  fontStyle: FontStyle.italic,
                ),
              ),
            ),
            const SizedBox(height: 28),

            // Nút mở bài báo gốc trên VnExpress
            SizedBox(
              width: double.infinity,
              height: 50,
              child: ElevatedButton.icon(
                onPressed: () => _openOriginalArticle(context),
                icon: const Icon(Icons.open_in_new, color: Colors.white),
                label: const Text(
                  'ĐỌC TOÀN BỘ BÀI VIẾT TRÊN VNEXPRESS',
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF9E1B32),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  elevation: 2,
                ),
              ),
            ),
            const SizedBox(height: 20),

            // Chân trang thông tin
            Center(
              child: Text(
                'Nội dung được phân phối qua kênh RSS chính thức của VnExpress',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 12,
                  color: isDark ? Colors.grey.shade500 : Colors.grey.shade600,
                ),
              ),
            ),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }
}
