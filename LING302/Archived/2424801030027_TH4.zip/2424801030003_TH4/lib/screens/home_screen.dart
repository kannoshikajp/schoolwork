import 'package:flutter/material.dart';
import '../models/news_article.dart';
import '../services/rss_service.dart';
import '../widgets/news_card.dart';
import 'article_detail_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final RssService _rssService = RssService();
  List<NewsArticle> _articles = [];
  bool _isLoading = true;
  String? _errorMessage;

  @override
  void initState() {
    super.initState();
    _loadNews();
  }

  Future<void> _loadNews() async {
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    try {
      // Tải tin tổng hợp từ RSS VnExpress
      final list = await _rssService.fetchArticles(
        'https://vnexpress.net/rss/tin-moi-nhat.rss',
        category: 'Tin tổng hợp',
      );

      setState(() {
        _articles = list;
        _isLoading = false;
      });
    } catch (e) {
      // Thử kênh tin-noi-bat làm fallback nếu cần
      try {
        final fallbackList = await _rssService.fetchArticles(
          'https://vnexpress.net/rss/tin-noi-bat.rss',
          category: 'Tin tổng hợp',
        );
        setState(() {
          _articles = fallbackList;
          _isLoading = false;
        });
      } catch (fallbackError) {
        setState(() {
          _isLoading = false;
          _errorMessage = 'Không thể kết nối đến VnExpress RSS. Vui lòng kiểm tra kết nối mạng và thử lại.';
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'ĐỌC BÁO ONLINE',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            letterSpacing: 1.2,
          ),
        ),
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            tooltip: 'Làm mới tin',
            onPressed: _loadNews,
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _loadNews,
        color: const Color(0xFF9E1B32),
        child: _buildBody(),
      ),
    );
  }

  Widget _buildBody() {
    if (_isLoading) {
      return const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircularProgressIndicator(
              color: Color(0xFF9E1B32),
            ),
            SizedBox(height: 16),
            Text(
              'Đang tải tin tức VnExpress...',
              style: TextStyle(fontSize: 14, color: Colors.grey),
            ),
          ],
        ),
      );
    }

    if (_errorMessage != null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(
                Icons.wifi_off_rounded,
                size: 60,
                color: Colors.redAccent,
              ),
              const SizedBox(height: 16),
              Text(
                _errorMessage!,
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 15),
              ),
              const SizedBox(height: 20),
              ElevatedButton.icon(
                onPressed: _loadNews,
                icon: const Icon(Icons.refresh),
                label: const Text('Thử lại'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF9E1B32),
                  foregroundColor: Colors.white,
                ),
              ),
            ],
          ),
        ),
      );
    }

    if (_articles.isEmpty) {
      return const Center(
        child: Text('Không có tin tức nào để hiển thị.'),
      );
    }

    return ListView.builder(
      physics: const AlwaysScrollableScrollPhysics(),
      itemCount: _articles.length,
      itemBuilder: (context, index) {
        final article = _articles[index];
        return NewsCard(
          article: article,
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => ArticleDetailScreen(article: article),
              ),
            );
          },
        );
      },
    );
  }
}
