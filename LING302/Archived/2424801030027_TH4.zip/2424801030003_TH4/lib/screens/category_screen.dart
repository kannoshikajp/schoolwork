import 'package:flutter/material.dart';
import '../models/news_article.dart';
import '../models/news_category.dart';
import '../services/rss_service.dart';
import '../widgets/news_card.dart';
import 'article_detail_screen.dart';

class CategoryScreen extends StatefulWidget {
  const CategoryScreen({super.key});

  @override
  State<CategoryScreen> createState() => _CategoryScreenState();
}

class _CategoryScreenState extends State<CategoryScreen> {
  final RssService _rssService = RssService();
  final List<NewsCategory> _categories = NewsCategory.defaultCategories;

  late NewsCategory _selectedCategory;
  List<NewsArticle> _articles = [];
  List<NewsArticle> _filteredArticles = [];
  bool _isLoading = true;
  String? _errorMessage;
  final TextEditingController _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    // Bỏ qua mục tổng hợp vì đã có ở Tab 1, mặc định chọn mục Thời sự
    _selectedCategory = _categories.length > 1 ? _categories[1] : _categories[0];
    _loadCategoryNews(_selectedCategory);
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _loadCategoryNews(NewsCategory category) async {
    setState(() {
      _selectedCategory = category;
      _isLoading = true;
      _errorMessage = null;
      _searchController.clear();
    });

    try {
      final list = await _rssService.fetchArticles(
        category.rssUrl,
        category: category.name,
        categoryId: category.id,
      );
      setState(() {
        _articles = list;
        _filteredArticles = list;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
        _errorMessage = 'Không thể tải tin cho chủ đề "${category.name}". Vui lòng thử lại.';
      });
    }
  }

  void _onSearch(String query) {
    if (query.isEmpty) {
      setState(() {
        _filteredArticles = _articles;
      });
    } else {
      final lower = query.toLowerCase();
      setState(() {
        _filteredArticles = _articles.where((item) {
          return item.title.toLowerCase().contains(lower) ||
              item.description.toLowerCase().contains(lower);
        }).toList();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'CHỦ ĐỀ TIN TỨC',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(60),
          child: Container(
            height: 52,
            padding: const EdgeInsets.symmetric(vertical: 6),
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              itemCount: _categories.length,
              separatorBuilder: (context, index) => const SizedBox(width: 8),
              itemBuilder: (context, index) {
                final cat = _categories[index];
                final isSelected = cat.id == _selectedCategory.id;

                return ChoiceChip(
                  avatar: Icon(
                    cat.icon,
                    size: 16,
                    color: isSelected
                        ? Colors.white
                        : (isDark ? Colors.white70 : Colors.black87),
                  ),
                  label: Text(cat.name),
                  selected: isSelected,
                  selectedColor: const Color(0xFF9E1B32),
                  labelStyle: TextStyle(
                    color: isSelected
                        ? Colors.white
                        : (isDark ? Colors.white70 : Colors.black87),
                    fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                    fontSize: 13,
                  ),
                  backgroundColor: isDark ? Colors.grey.shade800 : Colors.grey.shade200,
                  side: BorderSide.none,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20),
                  ),
                  onSelected: (selected) {
                    if (selected && cat.id != _selectedCategory.id) {
                      _loadCategoryNews(cat);
                    }
                  },
                );
              },
            ),
          ),
        ),
      ),
      body: Column(
        children: [
          // Khung tìm kiếm nhanh trong chủ đề
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
            child: TextField(
              controller: _searchController,
              onChanged: _onSearch,
              decoration: InputDecoration(
                hintText: 'Tìm kiếm tin trong "${_selectedCategory.name}"...',
                prefixIcon: const Icon(Icons.search, size: 20),
                suffixIcon: _searchController.text.isNotEmpty
                    ? IconButton(
                        icon: const Icon(Icons.clear, size: 18),
                        onPressed: () {
                          _searchController.clear();
                          _onSearch('');
                        },
                      )
                    : null,
                contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                filled: true,
                fillColor: isDark ? Colors.grey.shade800 : Colors.grey.shade100,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
          ),

          // Danh sách tin tức
          Expanded(
            child: RefreshIndicator(
              onRefresh: () => _loadCategoryNews(_selectedCategory),
              color: const Color(0xFF9E1B32),
              child: _buildBody(),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBody() {
    if (_isLoading) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const CircularProgressIndicator(color: Color(0xFF9E1B32)),
            const SizedBox(height: 16),
            Text(
              'Đang tải tin chủ đề "${_selectedCategory.name}"...',
              style: const TextStyle(fontSize: 14, color: Colors.grey),
            ),
          ],
        ),
      );
    }

    if (_errorMessage != null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.error_outline, size: 50, color: Colors.redAccent),
              const SizedBox(height: 12),
              Text(
                _errorMessage!,
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 14),
              ),
              const SizedBox(height: 16),
              ElevatedButton.icon(
                onPressed: () => _loadCategoryNews(_selectedCategory),
                icon: const Icon(Icons.refresh),
                label: const Text('Thử lại'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF9E1B32),
                  foregroundColor: Colors.white,
                ),
              ),
            ],
          ),
        ),
      );
    }

    if (_filteredArticles.isEmpty) {
      return const Center(
        child: Text('Không tìm thấy tin tức nào phù hợp.'),
      );
    }

    return ListView.builder(
      physics: const AlwaysScrollableScrollPhysics(),
      itemCount: _filteredArticles.length,
      itemBuilder: (context, index) {
        final article = _filteredArticles[index];
        return NewsCard(
          article: article,
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => ArticleDetailScreen(article: article),
              ),
            );
          },
        );
      },
    );
  }
}
