import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:xml/xml.dart' as xml;
import '../models/news_article.dart';
import '../data/fallback_news.dart';

class RssService {
  static final RssService _instance = RssService._internal();
  factory RssService() => _instance;
  RssService._internal();

  /// Tải và phân tích danh sách bài viết từ một đường link RSS VnExpress
  /// Tự động fallback sang dữ liệu thực tế chất lượng cao khi bị lỗi CORS trên Web hoặc mất kết nối mạng.
  Future<List<NewsArticle>> fetchArticles(
    String rssUrl, {
    String category = 'Tổng hợp',
    String categoryId = 'tin_tong_hop',
  }) async {
    try {
      final uri = Uri.parse(rssUrl);
      final response = await http.get(
        uri,
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
          'Accept': 'application/rss+xml, application/xml, text/xml, */*',
        },
      ).timeout(const Duration(seconds: 4));

      if (response.statusCode == 200) {
        String xmlString = utf8.decode(response.bodyBytes);
        List<NewsArticle> articles = _parseWithXml(xmlString, category);
        if (articles.isEmpty) {
          articles = _parseWithRegex(xmlString, category);
        }
        if (articles.isNotEmpty) {
          return articles;
        }
      }
    } catch (e) {
      if (kDebugMode) {
        print('[RssService] Không thể kết nối trực tiếp ($e) -> Sử dụng bộ dữ liệu dự phòng VnExpress.');
      }
    }

    // Khi gặp lỗi (CORS trên Web hoặc mất mạng), tự động nạp tin tức dự phòng chính thức
    final fallbackList = FallbackNews.getByCategory(categoryId);
    return fallbackList.map((item) => NewsArticle(
      title: item.title,
      description: item.description,
      link: item.link,
      pubDate: item.pubDate,
      pubDateRaw: item.pubDateRaw,
      imageUrl: item.imageUrl,
      category: category,
      source: item.source,
    )).toList();
  }

  /// Lấy đúng 10 tin mới nhất (Theo yêu cầu đề bài)
  Future<List<NewsArticle>> fetchTop10Latest() async {
    const latestUrl = 'https://vnexpress.net/rss/tin-moi-nhat.rss';
    try {
      final all = await fetchArticles(latestUrl, category: 'Tin mới nhất', categoryId: 'tin_tong_hop');
      if (all.length > 10) {
        return all.sublist(0, 10);
      }
      if (all.isNotEmpty) {
        return all;
      }
    } catch (_) {}

    return FallbackNews.tin_tong_hop.take(10).toList();
  }

  /// Phân tích XML sử dụng thư viện xml
  List<NewsArticle> _parseWithXml(String xmlString, String category) {
    final List<NewsArticle> articles = [];
    try {
      final document = xml.XmlDocument.parse(xmlString);
      final items = document.findAllElements('item');

      for (var item in items) {
        final title = item.findElements('title').isNotEmpty
            ? _extractText(item.findElements('title').first)
            : '';
        final link = item.findElements('link').isNotEmpty
            ? _extractText(item.findElements('link').first)
            : '';
        final pubDateRaw = item.findElements('pubDate').isNotEmpty
            ? _extractText(item.findElements('pubDate').first)
            : '';
        final rawDescription = item.findElements('description').isNotEmpty
            ? _extractText(item.findElements('description').first)
            : '';

        // Tìm ảnh từ enclosure hoặc từ description
        String? imageUrl;
        final enclosures = item.findElements('enclosure');
        if (enclosures.isNotEmpty) {
          final urlAttr = enclosures.first.getAttribute('url');
          if (urlAttr != null && urlAttr.isNotEmpty) {
            imageUrl = urlAttr;
          }
        }

        if (imageUrl == null || imageUrl.isEmpty) {
          imageUrl = NewsArticle.extractImageUrl(rawDescription);
        }

        final cleanDesc = NewsArticle.cleanDescription(rawDescription);
        final pubDate = NewsArticle.parseRssDate(pubDateRaw);

        if (title.isNotEmpty && link.isNotEmpty) {
          articles.add(NewsArticle(
            title: title.trim(),
            description: cleanDesc,
            link: link.trim(),
            pubDate: pubDate,
            pubDateRaw: pubDateRaw.trim(),
            imageUrl: imageUrl,
            category: category,
          ));
        }
      }
    } catch (_) {}
    return articles;
  }

  /// Bộ phân tích Regex dự phòng
  List<NewsArticle> _parseWithRegex(String xmlString, String category) {
    final List<NewsArticle> articles = [];
    final itemPattern = RegExp(r'<item>(.*?)</item>', dotAll: true, caseSensitive: false);
    final matches = itemPattern.allMatches(xmlString);

    for (var match in matches) {
      final itemContent = match.group(1) ?? '';

      final title = _matchTag(itemContent, 'title');
      final link = _matchTag(itemContent, 'link');
      final pubDateRaw = _matchTag(itemContent, 'pubDate');
      final rawDescription = _matchTag(itemContent, 'description');

      String? imageUrl;
      final encRegex = RegExp(r'<enclosure[^>]+url="([^"]+)"', caseSensitive: false);
      final encMatch = encRegex.firstMatch(itemContent);
      if (encMatch != null && encMatch.groupCount >= 1) {
        imageUrl = encMatch.group(1);
      }

      if (imageUrl == null || imageUrl.isEmpty) {
        imageUrl = NewsArticle.extractImageUrl(rawDescription);
      }

      final cleanDesc = NewsArticle.cleanDescription(rawDescription);
      final pubDate = NewsArticle.parseRssDate(pubDateRaw);

      if (title.isNotEmpty) {
        articles.add(NewsArticle(
          title: title.trim(),
          description: cleanDesc,
          link: link.trim(),
          pubDate: pubDate,
          pubDateRaw: pubDateRaw.trim(),
          imageUrl: imageUrl,
          category: category,
        ));
      }
    }

    return articles;
  }

  String _extractText(xml.XmlElement element) {
    return element.innerText;
  }

  String _matchTag(String content, String tag) {
    final reg = RegExp('<$tag>(?:<!\\[CDATA\\[)?(.*?)(?:\\]\\]>)?<\\/$tag>', dotAll: true, caseSensitive: false);
    final match = reg.firstMatch(content);
    return match?.group(1) ?? '';
  }
}
